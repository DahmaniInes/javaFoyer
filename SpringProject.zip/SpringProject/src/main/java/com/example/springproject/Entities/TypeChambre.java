package com.example.springproject.Entities;

public enum TypeChambre {SIMPLE , DOUBLE ,TRIPLE }
